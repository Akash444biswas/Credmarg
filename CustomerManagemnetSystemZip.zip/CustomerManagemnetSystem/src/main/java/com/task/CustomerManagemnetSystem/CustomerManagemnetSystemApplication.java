package com.task.CustomerManagemnetSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerManagemnetSystemApplication {
	public static void main(String[] args) {
		SpringApplication.run(CustomerManagemnetSystemApplication.class, args);
	}

}
